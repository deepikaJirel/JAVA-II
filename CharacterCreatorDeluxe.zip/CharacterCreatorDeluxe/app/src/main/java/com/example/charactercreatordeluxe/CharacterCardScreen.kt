package com.example.charactercreatordeluxe

@Composable
fun CharacterCardScreen(
    characterClass: CharacterClass?,
    stats: Map<String, Int>,
    onBackToStart: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        characterClass?.let {
            Text("${it.name} Card", style = MaterialTheme.typography.headlineMedium)
            Spacer(modifier = Modifier.height(16.dp))
            Text("Special Ability: ${it.ability}")
            Spacer(modifier = Modifier.height(8.dp))
            Text("Stats:")
            stats.forEach { (stat, value) ->
                Text("$stat: $value")
            }
        }
        Spacer(modifier = Modifier.height(16.dp))
        Button(
            onClick = onBackToStart,
            modifier = Modifier.align(Alignment.CenterHorizontally)
        ) {
            Text("Create Another Character")
        }
    }
}
