package com.example.charactercreatordeluxe


    @Composable
    fun SpendTalentsScreen(
        baseStats: Map<String, Int>,
        stats: Map<String, Int>,
        onStatsChange: (Map<String, Int>) -> Unit,
        onNext: () -> Unit,
        onCancel: () -> Unit
    ) {
        val maxPoints = 10
        val spentPoints = stats.values.sum() - baseStats.values.sum()
        val remainingPoints = maxPoints - spentPoints

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text("Spend Talent Points:", style = MaterialTheme.typography.headlineMedium)
            Text("Points Remaining: $remainingPoints")

            stats.forEach { (stat, value) ->
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(stat)
                    Row {
                        Button(
                            onClick = {
                                if (value > baseStats[stat] ?: 0) {
                                    onStatsChange(stats.toMutableMap().also { it[stat] = value - 1 })
                                }
                            },
                            enabled = value > baseStats[stat] ?: 0
                        ) { Text("-") }

                        Text(value.toString(), modifier = Modifier.padding(horizontal = 8.dp))

                        Button(
                            onClick = {
                                if (remainingPoints > 0) {
                                    onStatsChange(stats.toMutableMap().also { it[stat] = value + 1 })
                                }
                            }
                        ) { Text("+") }
                    }
                }
            }

            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.align(Alignment.CenterHorizontally)
            ) {
                Button(onClick = onCancel) { Text("Back") }
                Button(onClick = onNext, enabled = remainingPoints == 0) { Text("Next") }
            }
        }
    }

