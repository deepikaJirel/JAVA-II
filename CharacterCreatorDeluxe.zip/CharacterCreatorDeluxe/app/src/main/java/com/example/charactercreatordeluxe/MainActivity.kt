package com.example.charactercreatordeluxe

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            CharacterCreatorDeluxeApp()
        }
    }
}

@Composable
fun CharacterCreatorDeluxeApp() {
    val navController = rememberNavController()
    var selectedClass by remember { mutableStateOf<CharacterClass?>(null) }
    var stats by remember { mutableStateOf(emptyMap<String, Int>()) }

    Scaffold(topBar = { TopAppBar(title = { Text("Character Creator Deluxe") }) }) { padding ->
        NavHost(
            navController = navController,
            startDestination = "selectClass",
            modifier = Modifier.padding(padding)
        ) {
            composable("selectClass") {
                SelectClassScreen(
                    onClassSelected = {
                        selectedClass = it
                        stats = it.baseStats.toMap()
                        navController.navigate("spendPoints")
                    }
                )
            }
            composable("spendPoints") {
                SpendTalentsScreen(
                    baseStats = selectedClass?.baseStats ?: emptyMap(),
                    stats = stats,
                    onStatsChange = { stats = it },
                    onNext = { navController.navigate("characterCard") },
                    onCancel = { navController.popBackStack() }
                )
            }
            composable("characterCard") {
                CharacterCardScreen(
                    characterClass = selectedClass,
                    stats = stats,
                    onBackToStart = {
                        navController.popBackStack("selectClass", inclusive = false)
                    }
                )
            }
        }
    }
}

}