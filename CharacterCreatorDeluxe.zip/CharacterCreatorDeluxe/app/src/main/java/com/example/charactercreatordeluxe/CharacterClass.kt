package com.example.charactercreatordeluxe

data class CharacterClass(
    val name: String,
    val imageResId: Int,
    val baseStats: Map<String, Int>,
    val ability: String
)

val characterClasses = listOf(
    CharacterClass("Paladin", 0, mapOf("Strength" to 5, "Dexterity" to 2, "Intelligence" to 1), "Divine Shield"),
    CharacterClass("Mage", 0, mapOf("Strength" to 1, "Dexterity" to 3, "Intelligence" to 5), "Fireball"),
    CharacterClass("Rogue", 0, mapOf("Strength" to 2, "Dexterity" to 5, "Intelligence" to 2), "Stealth")
)

