package com.example.charactercreatordeluxe

@Composable
fun SelectClassScreen(onClassSelected: (CharacterClass) -> Unit) {
    var selectedOption by remember { mutableStateOf<CharacterClass?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text("Select a Class:", style = MaterialTheme.typography.headlineMedium)

        characterClasses.forEach { characterClass ->
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                RadioButton(
                    selected = selectedOption == characterClass,
                    onClick = { selectedOption = characterClass }
                )
                Text(text = characterClass.name)
            }
        }

        Button(
            onClick = { selectedOption?.let { onClassSelected(it) } },
            enabled = selectedOption != null,
            modifier = Modifier.align(Alignment.CenterHorizontally)
        ) {
            Text("Next")
        }
    }
}
