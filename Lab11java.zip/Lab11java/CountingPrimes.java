public class CountingPrimes {
    public static void main(String[] args) {
        Thread t1 = new Thread(() -> {
            printNumbers(1, 5);  // Threads that prints 1-5 first
            try { Thread.sleep(20); } catch (InterruptedException e) {}
            printNumbers(6, 10); // Then thread prints num from 6-10
        });

        Thread t2 = new Thread(() -> {
            try { Thread.sleep(10); } catch (InterruptedException e) {}
            printNumbers(1, 8);  // Thread 2 prints 1-8 after a small delay
            try { Thread.sleep(10); } catch (InterruptedException e) {}
            printNumbers(9, 10); // Then prints 9-10
        });

        t1.start();
        t2.start();
    }


    private static void printNumbers(int start, int end) {//method that prints num in a range
        
        for (int i = start; i <= end; i++) {
            System.out.println(i);
            try { Thread.sleep(5); } catch (InterruptedException e) {}
        }
    }
}