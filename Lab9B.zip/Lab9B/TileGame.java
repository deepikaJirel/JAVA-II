import java.util.ArrayDeque;
import java.util.Queue;

public class TileGame {
/**
* method to plaY the tile game
    @param stack take sstack of data
 * @param q takes the data
 * @return the number of turns
 */
    public static int tileGame(ArrayDeque<Integer> stack, Queue<Integer> q) {
        int turns = 0;

        while (!stack.isEmpty()) {
            int top = stack.pop();
            turns++;

            if (top == 1) {
            
                for (int i = 0; i < 1 && !stack.isEmpty(); i++) {
                    stack.pop();
                }
            } else if (top == 2) {
                
                for (int i = 0; i < 2 && !stack.isEmpty(); i++) {
                    stack.pop();
                }
            } else if (top == 3) {
                
                for (int i = 0; i < 3 && !q.isEmpty(); i++) {
                    stack.push(q.poll());
                }
            }
        }

        return turns;
    }

    public static void main(String[] args) {
        // Example Test Case from the PDF
        ArrayDeque<Integer> stack = new ArrayDeque<>();
        Queue<Integer> queue = new ArrayDeque<>();

//The stack is filled in reverse to ensure the first intended element ends up at the top
        stack.push(2);
        stack.push(1);
        stack.push(2);
        stack.push(3);

        
        int[] queueValues = {1, 2, 2, 1, 3, 1, 2, 1, 2, 3};//Queue values
        for (int val : queueValues) {
            queue.offer(val);
        }

        int turns = tileGame(stack, queue);
        System.out.println("Given stack and queue took " + turns + " turns to finish playing");
    }
}
