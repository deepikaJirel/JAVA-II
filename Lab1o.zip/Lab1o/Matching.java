public class Matching {

    public static void main(String[] args) {
        System.out.println("Counting down from 10 to 3:");//prints num counting down from 10 to 3.
        countDown(10, 3);

        System.out.println("\nCounting down from 4 to 5:");//prints num counting down from 4 to 5.
        countDown(4, 5);

        System.out.println("\nCounting down from -2 to -6:");//prints number counting from -2 to -6.
        countDown(-2, -6);
    }

    public static void countDown(int start, int stop) {
        if (stop > start) {
            return;
        }

        System.out.print(start + " ");
        countDown(start - 1, stop);//REcursion to next lower number.
    }
}
