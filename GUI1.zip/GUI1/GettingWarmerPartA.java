import java.awt.FlowLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class GettingWarmerPartA {
    public static void main(String[] args) {
        JFrame mainWindow = new JFrame("Getting Warmer");
        mainWindow.setLocation(0, 0);
        mainWindow.setSize(1000, 1000);
        mainWindow.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel panel = new JPanel();
        panel.setLayout(new FlowLayout());
        JButton convertButton = new JButton("Convert");
        panel.add(convertButton);
        
        mainWindow.setContentPane(panel);// Set content pane of  main window to the panel
        mainWindow.setVisible(true); //  window is visible
    }
}
