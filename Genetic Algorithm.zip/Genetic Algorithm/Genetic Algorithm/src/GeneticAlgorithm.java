import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;
import java.util.Scanner;

	/**
 * The Chromosome class represents a potential solution to the bin-packing problem.
 * It extends ArrayList<Item> and implements Comparable<Chromosome> for genetic operations.
 */
class GeneticAlgorithm {

    private static final int populationSize = 10; // Number of chromosomes in population
    private static final int generations = 20; // Number of generations to run
    private static final double mutationRate = 10/100; // 10% mutation rate

    /**
     * Reads item data from a file and creates an ArrayList of Item objects.
     * The file should contain lines in the format: name, weight, value
     * 
     * @param filename The name of the file to read from.
     * @return ArrayList of Item objects.
     * @throws FileNotFoundException If the file is not found.
     */
    public static ArrayList<Item> readData(String filename) throws FileNotFoundException {
        ArrayList<Item> items = new ArrayList<>();
        File file = new File(filename);

        Scanner scanner = new Scanner(file);
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                String[] parts = line.split(",");//splits with coma
                if (parts.length == 3) {
                    String name = parts[0].trim();//
                    double weight = Double.parseDouble(parts[1].trim());
                    int value = Integer.parseInt(parts[2].trim());
                    items.add(new Item(name, weight, value));
                }
            }
            scanner.close();
        // } catch (NumberFormatException e) {
        //     System.err.println("Error");
        // }

        return items;
    }

    /**
     * Initializes the population of Chromosomes.
     * Each Chromosome is initialized with a copy of the list of items,
     * and each item's included field is randomly set to true or false.
     * 
     * @param items The list of items to be included in each Chromosome.
     * @param populationSize The number of Chromosomes in the population.
     * @return ArrayList of Chromosomes representing the population.
     */
    public static ArrayList<Chromosome> initializePopulation(ArrayList<Item> items, int populationSize) {
        ArrayList<Chromosome> population = new ArrayList<>();
       // Random rng = new Random();

        while (population.size() < populationSize) {
            Chromosome chromosome = new Chromosome(items);
            population.add(chromosome);
        }

        return population;
    }

    /**
     * Main method to run the genetic algorithm.
     * It initializes the population, performs crossover and mutation,
     * and displays the fittest and least fit Chromosomes.
     * 
     * @param args Command line arguments (not used).
     * @throws FileNotFoundException If the input file is not found.
     */
    public static void main(String[] args) throws FileNotFoundException {
        // Step 1: Read Item Data from File
        ArrayList<Item> items = readData("Items.txt");
        ArrayList<Chromosome> population = initializePopulation(items, populationSize);// Initialize Population

        for (int i = 0; i < generations; i++) {//Run Genetic Algorithm Loop
            ArrayList<Chromosome> nextGeneration = new ArrayList<>(population);

            // Crossover: Pair off individuals and create children
            Random rng = new Random();
            while (nextGeneration.size() < populationSize * 2) {
                Chromosome parent1 = population.get(rng.nextInt(population.size()));
                Chromosome parent2 = population.get(rng.nextInt(population.size()));
                Chromosome child = parent1.crossover(parent2);
                nextGeneration.add(child);
            }

            
            for (Chromosome chromosome : nextGeneration) {// Mutation: 10% chance to mutate each Chromosome
                if (rng.nextDouble() < mutationRate) {
                    chromosome.mutate();
                }
            }

            Collections.sort(nextGeneration);// Selection Arranged by fitness and select the top 10 for the next generatio
            population = new ArrayList<>(nextGeneration.subList(0, populationSize));
        }
        Collections.sort(population);//Display Results

        // Display the Fittest Chromosome
        System.out.println("Fittest Chromosome:");
        System.out.println(population.get(0));
        

    }
}

