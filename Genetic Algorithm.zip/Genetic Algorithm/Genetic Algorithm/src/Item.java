/**
*Item represents attributes such as name, weight, value, and inclusion.
 * Cloneable is implemented to support deep copying of item instances.
 */
public class Item implements Cloneable {

    private final String name; //  Name of the item
    private final double weight; // Weight of the item in pounds
    private final int value; //Worth of the item in dollars
    private boolean included; // Shows item is included or not
    private static int counter = 0; // Generates unique  numbers for the item
    private final int itemNumber; // Unique identifier

    /**
     * Constructs an Item with the specified parameters
     * 
     * @param name   Name of an item.
     * @param weight Weight of the item in pounds.
     * @param value  Value of the item in dollars.
     */
    public Item(String name, double weight, int value) {
        this.name = name;
        this.weight = weight;
        this.value = value;
        this.included = false;
        this.itemNumber = ++counter;
    }

    /**
     * Copies the constructor to make  new Item instance based on an existing one.
     * @param other The Item to be copied.
     */
    public Item(Item other) {
        this.name = other.name;
        this.weight = other.weight;
        this.value = other.value;
        this.included = other.included;
        this.itemNumber = other.itemNumber;
    }

    /**
     *
     * @return Weight of the item in pounds.
     */
    public double getWeight() {
        return weight;
    }

    /**
     * @return The value of the item in dollars.
     */
    public int getValue() {
        return value;
    }

    /**
     * @return True if the item is included else returns false
     */
    public boolean isIncluded() {
        return included;
    }

    /**
     *
     * @param included True to include the item otherwise false to exclude it.
     */
    public void setIncluded(boolean included) {
        this.included = included;
    }

    /**
     *
     * @return String representation of the item.
     */
    @Override
    public String toString() {
        return name + " (" + weight + " lbs, $" + value + ")";
    }

    /**
     * Creates a deep copy of the current item
     * 
     * @return  A new Item instance that is a clone of this item
     */
    @Override
    protected Object clone() {
        return new Item(this); //returns a new instance using the copy constructor
    }
}
