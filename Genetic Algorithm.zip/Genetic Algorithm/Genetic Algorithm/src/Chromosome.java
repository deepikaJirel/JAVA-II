import java.util.ArrayList;
import java.util.Random;

/**
 * Chromosome class represents a potential solution to the bin-packing problem.
 * Extends ArrayList<Item> and implements Comparable<Chromosome> is used for
 * genetic operations.
 */
public class Chromosome extends ArrayList<Item> implements Comparable<Chromosome> {

    private static final long serialVersionUID = 1L;
    private static Random rng = new Random();
    private static double totalWeight; // store total weight of included items
    private static int totalValue; // store total value of included items

    public Chromosome() {//default constructor
        super();
    }

    /**
     * Constructs a Chromosome from a list of items.
     * Randomly sets the included field for each item.
     * 
     * @param items list of item to include in chromosome.
     */
    public Chromosome(ArrayList<Item> items) {
        for (Item item : items) {// Makes copy of the item
            Item copy = new Item(item);
            
            copy.setIncluded(rng.nextBoolean());// decides randomly if the item is included or not
            this.add(copy);
        }
    }

    /**
     * Performs crossover with another Chromosome to create a child.
     * For each item, randomly chooses the gene from either this or the other
     * parent.
     * 
     * @param other The other Chromosome to crossover with.
     * @return A new child Chromosome created from the crossover operation.
     */
    public Chromosome crossover(Chromosome other) {
        Chromosome child = new Chromosome();
        for (int i = 0; i < this.size(); i++) {
            Item gene = (rng.nextInt(10) < 5) ? this.get(i) : other.get(i);// choses the gene from one of the parent
            child.add(new Item(gene)); // Add a copy of item in gene
        }
        return child;
    }

    /**
     * Mutates the Chromosome by flipping the included status of each item with a
     * 10% chance.
     */
    public void mutate() {
        for (Item item : this) {
            if (rng.nextInt(10) == 0) {
                item.setIncluded(!item.isIncluded());
            }
        }
    }

    /**
     * Calculates the fitness of the Chromosome based on the total weight and value
     * of included items.
     * If the total weight exceeds 10, the fitness is set to 0.
     * 
     * @return The fitness of this Chromosome.
     */
    public int getFitness() {
        totalWeight = 0;
        totalValue = 0;
        for (Item item : this) {
            if (item.isIncluded()) {// Calculates the total weight and value of included items
                totalWeight += item.getWeight();
                totalValue += item.getValue();
            }
        }
        return (totalWeight > 10) ? 0 : totalValue; // Return fitness based on total weight

    }

    /**
     * Compares this Chromosome with another based on fitness.
     * 
     * @param other The other Chromosome to compare against.
     * @return -1 if this Chromosome is fitter, +1 if the other is fitter, 0 if both
     *         have equal fitness.
     */
    @Override
    public int compareTo(Chromosome other) {
        return Integer.compare(other.getFitness(), this.getFitness());
    }

    /**
     * Provides a string representation of the Chromosome.
     * Displays the details of included items and the total fitness.
     * 
     * @return A string representation of the Chromosome.
     */
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder("Chromosome:\n");
        for (Item item : this) {
            if (item.isIncluded()) {
                sb.append(item.toString()).append("\n");//appends add string; used string builder
            }
        }
        sb.append("Total Fitness: ").append(getFitness());
        return sb.toString();
    }
}
