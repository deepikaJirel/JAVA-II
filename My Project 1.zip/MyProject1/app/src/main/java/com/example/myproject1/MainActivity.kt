package com.example.myproject1

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ThumbUp
import androidx.compose.material.icons.outlined.ThumbUp
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            CharacterCardTheme {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(CardBackgroundColor),
                    contentAlignment = Alignment.Center
                ) {
                    CharacterCard()
                }
            }
        }
    }
}

@Composable
fun CharacterCardTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = lightColorScheme(),
        typography = Typography(),
        content = content
    )
}

val CardBackgroundColor = Color(0xFF0073A2)

@Composable
fun CharacterCard() {
    Column(
        modifier = Modifier
            .width(320.dp)
            .border(BorderStroke(3.dp, Color.Black), RoundedCornerShape(8.dp))
            .background(Color.White)
            .padding(8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        CharacterTitleBar()
        CharacterImage()
        CharacterType()
        CharacterDescription()
        CharacterStats()
    }
}

@Composable
fun CharacterTitleBar() {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(6.dp)
            .border(1.dp, Color.Black, RoundedCornerShape(4.dp))
            .background(Color.White)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(6.dp),
            horizontalArrangement = Arrangement.Start,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Drinkyelf",
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(6.dp)
            )
        }

        Row(
            modifier = Modifier
                .align(Alignment.CenterEnd)
                .padding(end = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "5 ⚠",
                fontSize = 18.sp,
                color = Color.Red,
                modifier = Modifier.padding(end = 6.dp)
            )
        }
    }
}

@Composable
fun CharacterImage() {
    Image(
        painter = painterResource(id = R.drawable.character_image),
        contentDescription = "Character Image",
        modifier = Modifier
            .fillMaxWidth()
            .height(200.dp)
            .clip(RoundedCornerShape(8.dp))
            .border(2.dp, Color.Black, RoundedCornerShape(8.dp)),
        contentScale = ContentScale.Crop
    )
}

@Composable
fun CharacterType() {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color(0xFFDADADA))
            .padding(6.dp)
            .border(1.dp, Color.Black),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = "Night Elf Rogue",
            fontSize = 18.sp,
            fontWeight = FontWeight.Medium,
            modifier = Modifier.weight(1f)
        )

        var isLiked by remember { mutableStateOf(false) }

        IconButton(
            onClick = { isLiked = !isLiked },
            modifier = Modifier.size(24.dp)
        ) {
            Icon(
                imageVector = if (isLiked) Icons.Filled.ThumbUp else Icons.Outlined.ThumbUp,
                contentDescription = "Like Button",
                tint = if (isLiked) Color.Blue else Color.Gray
            )
        }
    }
}

@Composable
fun CharacterDescription() {
    Text(
        text = "When an enemy is damaged by Drinkyelf, they become poisoned, up to five stacks. Each round a creature is poisoned, each turn it takes damage equal to the number of stacks of poison.",
        fontSize = 14.sp,
        modifier = Modifier
            .fillMaxWidth()
            .padding(6.dp)
            .border(BorderStroke(1.dp, Color.Black))
            .padding(6.dp)
    )
}

@Composable
fun CharacterStats() {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(6.dp),
        horizontalArrangement = Arrangement.End
    ) {
        Text(
            text = "3 / 2",
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold
        )
    }
}

@Preview(showBackground = true)
@Composable
fun PreviewCard() {
    CharacterCardTheme {
        CharacterCard()
    }
}
