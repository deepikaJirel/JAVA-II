public class Game {
    public static void main(String[] args) {
        Player onePunchMan = new Player("One Punch Man", 15);
        Player alien = new Player("Alien", 5);

        while (onePunchMan.getHealth() > 0 && alien.getHealth() > 0) {
            onePunchMan.dealDamage(alien);
            alien.dealDamage(onePunchMan);
            System.out.println(onePunchMan + " " + alien);
        }

        Player winner = onePunchMan.getHealth() > 0 ? onePunchMan : alien;
        System.out.println("Winner is " + winner);
    }
}
