import java.util.Random;

public class Player {

    private String name;
    private int health;
    private int maxDamage;

    /**
     *
     * @param name passes name as an parameter while creating an object
     * @param maxDamage  passes maxDage int while creating an object.
     */
    public Player(String name, int maxDamage) {
        this.name = name;
        this.health = 100;
        this.maxDamage = maxDamage;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setHealth(int health) {
        this.health = health;
    }

    public int getHealth() {
        return health;
    }

    public void setMaxDamage(int maxDamage) {
        this.maxDamage = maxDamage;
    }

    public int getMaxDamage() {
        return maxDamage;
    }

    /**
     * @param p passes the player object having two parameter name & maxDamage:
     */
    public void dealDamage(Player p) {
        Random random = new Random();
        int damage = random.nextInt(p.getMaxDamage() + 1);
        this.health -= damage;
    }

    @Override
    public String toString() {
        return name + ": HP " + health;
    }
}