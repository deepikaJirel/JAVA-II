public class SecureUser extends User {

    private int failedAttempts; //  stores the  consecutive failed authentications
    private final int maxAttempts = 3; // maximum number of failed attempt
    private boolean isLocked; //checks if the account is locked

    public SecureUser(String username, String password) {
        super(username, password);
        this.failedAttempts = 0;
        this.isLocked = false;
    }

    @Override
    public boolean authenticate(String inputPassword) {
        if (isLocked) {
            System.out.println("Sorry! The account is locked due to multiple attempts.");
            return false;
        }

        if (super.authenticate(inputPassword)) {
            failedAttempts = 0; // Reset failed attempts on success
            return true;
        } else {
            failedAttempts++;
            System.out.println("Authentication failed. Failed attempts: " + failedAttempts);
            if (failedAttempts >= maxAttempts) {
                isLocked = true;
                System.out.println("This account is locked now.");
            }
            return false;
        }
    }

    public void unLocked() {
        this.failedAttempts = 0;
        this.isLocked = false;
        System.out.println("This locked account has been reset.");
    }
}