/**
 * The Matching class provides a method to determine whether a given string
 * is a proper nesting of zero or more pairs of parentheses.
 */

public class Matching {
    /*
     * The main method contains test cases to demonstrate the functionality
     * of the nestParen method.
     * 
     * @param args not used.
     */

    public static void main(String[] args) {
        // test cases
        System.out.println("nestParen(\"(())\") -> " + nestParen("(())"));
        System.out.println("nestParen(\"((()))\") -> " + nestParen("((()))"));
        System.out.println("nestParen(\"(((x))\") -> " + nestParen("(((x))"));
        System.out.println("nestParen(\"((())\") -> " + nestParen("((())"));
        System.out.println("nestParen(\"((()()\") -> " + nestParen("((()()"));
        System.out.println("nestParen(\"\") -> " + nestParen(""));
        System.out.println("nestParen(\"(yy)\") -> " + nestParen("(yy)"));
        System.out.println("nestParen(\"((yy())))\") -> " + nestParen("((yy())))"));
    }

    /**
     * Returns true if the input string is a valid nesting of zero or more pairs
     * of parentheses. A valid nesting means that each opening parenthesis '('
     * has a corresponding closing parenthesis ')' and are ordered properly.
     * 
     * @param n the input string that checks
     * @return true if the string is a valid nesting of parentheses else false.
     */

    public static boolean nestParen(String n) {
        if (n.length() == 0) {
            return true;
        }
        if (n.length() == 1) {
            return false;
        }
        if (n.charAt(0) == '(' && n.charAt(n.length() - 1) == ')') {
            return nestParen(n.substring(1, n.length() - 1));
        }
        return false;
    }
}
