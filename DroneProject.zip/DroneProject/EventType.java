
/**
 * Enum representing types of events that can occur in the simulation.
 */
public enum EventType {
    TRAIN_START,
    TRAIN_END,
    TRUCK_START,
    TRUCK_END,
    TRUCK_AT_CROSSING,
    TRUCK_CROSS
}
