
/**
 * Represents a scheduled event in the simulation.
 */
public class Event implements Comparable<Event> {
    double time;
    EventType type;
    Truck truck;
    String description;

    /**
     *
     * @param time
     * @param type
     * @param truck
     * @param description
     */
    public Event(double time, EventType type, Truck truck, String description) {
        this.time = time;
        this.type = type;
        this.truck = truck;
        this.description = description;
    }
    @Override
    public int compareTo(Event o) {
        if(this.time != o.time) {
            return Double.compare(this.time, o.time);
        }
        return this.typePriority() - o.typePriority();
    }
    private int typePriority() {
        switch (this.type) {
            case TRAIN_START:
                case TRAIN_END:
                    return 0;
            case TRUCK_AT_CROSSING:
                return 1;
                default:
                    return 2;

        }
    }
}
