import java.util.LinkedList;
import java.util.Queue;

/**
 * Represents the train track and manages blocked status and waiting trucks.
 */
public class TrainTruck {
    boolean isBlocked;
    Queue<Truck> waitingTrucks;
    double currentBlockEndTime;

    public TrainTruck() {
        this.isBlocked = false;
        this.waitingTrucks = new LinkedList<>();
        this.currentBlockEndTime = -1;
    }

    public void blockTrack() {
        this.isBlocked = true;
    }

    public void unblockTrack() {
        this.isBlocked = false;
    }

    public void addWaitingTruck(Truck truck) {
        waitingTrucks.add(truck); //adding truck object to list:
    }

    public Truck getNextWaitingTruck() {
        return waitingTrucks.poll();
    }

    public boolean hasWaitingTrucks() {
        return !waitingTrucks.isEmpty();
    }
}
