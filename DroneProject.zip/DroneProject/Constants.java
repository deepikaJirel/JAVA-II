/* this call holds various constants values used in delivery simulation  */
public class Constants {

    public static final double TRUCK_SPEED = 60;
    public static final double TRUCK_DISTANCE_TO_CROSSING = 50;
    public static final double TRUCK_DISTANCE_AFTER_CROSSING = 50;
    public static final double TRUCK_DEPARTURE_OFFSET = 15.0;
    public static final double DRONE_ACCELERATION = 34.6;
    public static final double DRONE_DISTANCE = 10000; // meters (10 km)
}