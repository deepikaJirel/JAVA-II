/**
 * Represents a truck in the simulation.
 */
public class Truck {
    int id;
    double startTime;
    double tripTime;

    /**
     *
     * @param id tracking truck number:
     * @param startTime tracking truck startTime:
     */
    public Truck(int id, double startTime) {
        this.id = id;
        this.startTime = startTime;
    }
}
