import java.util.ArrayDeque;
import java.util.Queue;
import java.util.Stack;

public class TiledTask {
    public static void main(String[] args) {

        Stack<Integer> s = new Stack<>();// Crates stack
        s.push(9);// adding the integer in the stack
        s.push(6);
        s.push(4);
        s.push(2);
        s.push(5);
        s.push(1);
        s.push(3);

        System.out.println("Stack contents: ");//prints the stacks
        while (!s.isEmpty()) {
            System.out.println(s.pop() + " ");
        }
        System.out.println();

        Queue<Integer> pq = new ArrayDeque<>();//creates queue 
        pq.offer(9);//adds integer in the queue
        pq.offer(6);
        pq.offer(4);
        pq.offer(2);
        pq.offer(5);
        pq.offer(1);
        pq.offer(3);
        
        System.out.println("Queue contents: ");//print out the queue
        while (!pq.isEmpty()) {
            System.out.println(pq.poll() + " ");
        }
        System.out.println();
    }
}
